using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System;
using System.Linq;
using System.Threading.Tasks;
using project;

namespace project.Models
{
    public class Data
    {
        public String name {get; set;}

        public String address {get; set;}

        public double X {get; set;}

        public double Y {get; set;}   

        public String number {get; set;}     
    }    
}